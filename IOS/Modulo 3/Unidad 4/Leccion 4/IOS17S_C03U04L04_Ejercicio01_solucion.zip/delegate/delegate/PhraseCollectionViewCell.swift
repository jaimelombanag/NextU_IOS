//
//  PhraseCollectionViewCell.swift
//  delegate
//
//  Created by Integro on 16/03/17.
//  Copyright © 2017 nextu. All rights reserved.
//

import UIKit

class PhraseCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var phraseLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
