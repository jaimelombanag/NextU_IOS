//
//  HeaderFooterView.swift
//  Consoles
//
//  Created by Luis F Ruiz Arroyave on 3/11/17.
//  Copyright © 2017 nextu. All rights reserved.
//

import UIKit

class HeaderFooterView: UICollectionReusableView {
        //MARK: - IBOutlets
    
    @IBOutlet weak var imageViewHeader: UIImageView!
    @IBOutlet weak var imageViewFooter: UIImageView!
    
}
