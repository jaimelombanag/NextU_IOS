//
//  ColorCell.swift
//  Colors
//
//  Created by Luis F Ruiz Arroyave on 3/11/17.
//  Copyright © 2017 nextu. All rights reserved.
//

import UIKit

class ColorCell: UICollectionViewCell {
    
    @IBOutlet weak var colorView: UIView!
    
}
