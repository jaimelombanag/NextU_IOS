//
//  PhraseCell.swift
//  FrasesCelebres
//
//  Created by Luis F Ruiz Arroyave on 12/22/15.
//  Copyright © 2015 NextU. All rights reserved.
//

import UIKit

class PhraseCell: UICollectionViewCell {
    
    @IBOutlet weak var phraseLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
}
